﻿using DiscordRPC;
namespace EasyRPC
{
	public class RPC
	{
		public static DiscordRpcClient client;
		public static Timestamps rpctimestamp { get; set; }
		private static RichPresence presence;
		public static void InitializeRPC()
		{
			//Discord Bot ID
			client = new DiscordRpcClient("906632997103603762");
			client.Initialize();
			//Buttons Discord / Youtube
			Button[] buttons = { new Button() { Label = "Discord", Url = "https://discord.gg/n4Qaem58qU" }, new Button() { Label = "YouTube", Url = "https://www.youtube.com/channel/UC-z-7vnmmDHDkfjaZnq52zQ" } };

			presence = new RichPresence()
			{
				
				State = "Watching",
				Timestamps = rpctimestamp,
				Buttons = buttons,

				Assets = new Assets()
				{
					LargeImageKey = "logo",
					LargeImageText = "text",
					SmallImageKey = "logo",
					SmallImageText = "text"
				}
			};
			SetState("Watching");
		}
		public static void SetState(string state, bool watching = false)
		{
			if (watching) 
				state = "Watching " + state;

			presence.State = state;
			client.SetPresence(presence);
		}
	}
}
